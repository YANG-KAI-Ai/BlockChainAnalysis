var baseUrl = window.location.protocol + "//" + window.location.host + "/";


$(function () {
    // var width = $(".fTnfND").width();
    // var left = $(".fTnfND").offset().left - 48;
    // $(".ktYdPx").css({"width": width + "px", "left": left + "px", "display": "block"})
})
$(document).ready(function () {
    // 是否登录
    var loginFlag = true;
    // 未登录，显示遮罩层
    if (!loginFlag) {
        $(".col-section-main-mask").addClass("col-section-main-mask-show");
    }

    // 第一行
    // 加载表头
    var body = '<div class="col-section-main-table-header col-section-main-table-row sc-jdhwqr sc-iLOkMM bMMZGs iYxCeC">';
    var tableHeader = ["Time","Market Price Usd","Hash Rate","Total Fees Btc","N Btc Mined","N Tx","N Blocks Mined", "Minutes Between Blocks", "Totalbc", "N Blocks Total", "Estimated Transaction Volume Usd", "Blocks Size", "Miners Revenue Usd", "Nextretarget", "Difficulty", "Estimated Btc Sent", "Miners Revenue Btc", "Total Btc Sent", "Trade Volume Btc", "Trade Volume Usd"]
    var index = 0;
    for (const title of tableHeader) {
        var template = template_table_header;
        template = template.replace("{{title}}", title);
        template = template.replace("{{index}}", index++);
        var fixedValue = "";
        if (index === 0) {
            fixedValue = "data-fixed=\"true\"";
        }
        template = template.replace("{{fixed}}", fixedValue);
        body += template;
//        $("#one-one-section .col-section-main-table-header").append(template);
    }
    body += '</div>';

    var grid_template_columns = "";
    for (let i = 0; i < tableHeader.length; i++) {
        grid_template_columns += "auto ";
    }
    $("#one-one-section").css({"grid-template-columns": grid_template_columns});
    // 加载数据
    function oneOneSectionLoadData() {
            var bodyNew = body;
            var template_1_1_column = '';

            for (var i = 0; i < tableHeader.length; i++) {
                var template = template_1_1_column_temp;

                template = template.replace("{{value}}", tableHeader[i]);
                template = template.replace("{{columnIndex}}", i);
                template_1_1_column += template
            }

            queryData(baseUrl+"showHotBlockChainToken", {}, function (resp) {
                resp = $.parseJSON(resp);
                if (!resp || !resp.length){
                    console.log("获取列表为空")
                    return
                }
                $("#one-one-section").find(".col-section-main-table-item").remove()

                for (var r of resp) {
                    r = $.parseJSON(r);
                    var template = template_1_1_column;
                   template = template.replace(tableHeader[0], r.timestamp);
                   template = template.replace(tableHeader[1], r.market_price_usd);
                   template = template.replace(tableHeader[2], r.hash_rate);
                   template = template.replace(tableHeader[3], r.total_fees_btc);
                   template = template.replace(tableHeader[4], r.n_btc_mined);
                   template = template.replace(tableHeader[5], r.n_tx);
                   template = template.replace(tableHeader[6], r.n_blocks_mined);
                   template = template.replace(tableHeader[7], r.minutes_between_blocks);
                   template = template.replace(tableHeader[8], r.totalbc);
                   template = template.replace(tableHeader[9], r.n_blocks_total);
                   template = template.replace(tableHeader[10], r.estimated_transaction_volume_usd);
                   template = template.replace(tableHeader[11], r.blocks_size);
                   template = template.replace(tableHeader[12], r.miners_revenue_usd);
                   template = template.replace(tableHeader[13], r.nextretarget);
                   template = template.replace(tableHeader[14], r.difficulty);
                   template = template.replace(tableHeader[15], r.estimated_btc_sent);
                   template = template.replace(tableHeader[16], r.miners_revenue_btc);
                   template = template.replace(tableHeader[17], r.total_btc_sent);
                   template = template.replace(tableHeader[18], r.trade_volume_btc);
                   template = template.replace(tableHeader[19], r.trade_volume_usd);


                    var template_row = template_1_1_row;
                    template_row = template_row.replace("{{body}}", template);
    //                $("#one-one-section").append(template_row)
    //                $("#1_1_row").append(template)
                    bodyNew += template_row;
                }
                $("#one-one-section").html(bodyNew)
            });
        }
    oneOneSectionLoadData();
    setInterval(oneOneSectionLoadData, 2000);
    // 第二行
    // 加载表头
//    var towOneSectionTableHeader = ["Network", "Name", "Balance", "Pool Token Holders", "Holders", "Ownership", "Txs (7D)",  "Txs (7D)", "First Seen"]
//    var index = 0;
//    for (const title of towOneSectionTableHeader) {
//        var template = template_table_header;
//        template = template.replace("{{title}}", title);
//        template = template.replace("{{index}}", index++);
//        var fixedValue = "";
//        if (index === 0) {
//            fixedValue = "data-fixed=\"true\"";
//        }
//        template = template.replace("{{fixed}}", fixedValue);
//        $("#two-one-section .col-section-main-table-header").append(template);
//    }
//    var grid_template_columns2 = "";
//    for (let i = 0; i < towOneSectionTableHeader.length; i++) {
//        grid_template_columns2 += "auto ";
//    }
//    $("#two-one-section").css({"grid-template-columns": grid_template_columns2});
//    // 加载数据
//    function twoOneSectionLoadData() {
//        queryData("data-3-1.json", {}, function (resp) {
//            if (!resp || !resp.data || !resp.data.length){
//                console.log("获取列表为空")
//                return
//            }
//            // $("#two-one-section").find(".col-section-main-table-item").remove()
//            // for (const r of resp.data) {
//            //     var template = template_3_1;
//            //     template = template.replace("{{headline}}", r.headline);
//            //     template = template.replace("{{date}}", r.date);
//            //     $("#tow-one-section").append(template)
//            // }
//        });
//    }
//    twoOneSectionLoadData();
});

function showConditionDialog() {
    $("#dialog-windows").removeClass("hide");
    // $(".layui-nav-bar").css({"display": "none"})
}

function hideConditionDialog() {
    $("#dialog-windows").addClass("hide");
}

var template_table_header =
"<div class=\"col-section-main-table-header-col sc-ezHhwS bpEKFQ\" data-target=\"cell\" {{fixed}} data-column=\"{{index}}\">\n" +
"    <div class=\"sc-dYtuZ iqUusz\">\n" +
"        <div data-target=\"inner\" data-type=\"wallet\" class=\"sc-kBzgEd iMgJry\" style=\"max-width: 250px;\">\n" +
"            <span data-target=\"formatted\" class=\"sc-gJbFto gFORgR\" style=\"max-width: 250px;\">\n" +
"                <span>\n" +
"                    <span class=\"\">{{title}}</span>\n" +
"                </span>\n" +
"            </span>\n" +
"        </div>\n" +
"    </div>\n" +
"</div>";

var template_1_1_row =
    "<div data-row=\"row-0\" data-idx=\"0\" class=\"sc-jdhwqr sc-fkJVfC sc-iuqRDJ kCuHoQ cpknaP fEywaC\">\n" +
    "    {{body}}\n" +
    "</div>";
var template_1_1_link_column =
    "<a data-target=\"cell\" data-column=\"{{columnIndex}}\" data-fixed=\"true\" role=\"button\" data-cy=\"tbl-defi-paradise-liquidity-pool-body-row-0-col-0\" href=\"{{link}}\" rel=\"noopener noreferrer\" target=\"_blank\" class=\"sc-ezHhwS gKlIHZ\">\n" +
    "    <div class=\"sc-dYtuZ iqUusz\">\n" +
    "        <div data-target=\"inner\" data-type=\"wallet\" class=\"sc-kBzgEd eUNGNJ\" style=\"max-width: 250px;\">\n" +
    "\t\t\t\t<span data-target=\"formatted\" class=\"sc-gJbFto iNyjQm\" style=\"max-width: 250px;\">\n" +
    "\t\t\t\t\t<span>\n" +
    "\t\t\t\t\t\t<span class=\"\">{{value}}</span>\n" +
    "\t\t\t\t\t</span>\n" +
    "\t\t\t\t</span>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</a>";
var template_1_1_column_temp =
    "<div data-target=\"cell\" data-column=\"{{columnIndex}}\" data-cy=\"tbl-defi-paradise-liquidity-pool-body-row-0-col-1\"\n" +
    "     class=\"sc-ezHhwS cyzOVl\">\n" +
    "    <div class=\"sc-dYtuZ iqUusz\">\n" +
    "        <div data-target=\"inner\" data-type=\"default\" class=\"sc-kBzgEd eUNGNJ\" style=\"max-width: 250px;\">\n" +
    "\t\t\t\t<span data-target=\"formatted\" class=\"sc-gJbFto iNyjQm\" style=\"max-width: 250px;\">\n" +
    "\t\t\t\t\t<span>\n" +
    "\t\t\t\t\t\t<span class=\"\">{{value}}</span>\n" +
    "\t\t\t\t\t</span>\n" +
    "\t\t\t\t</span>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>";


// var template_3_1 = "<div class=\"col-section-main-table-item col-section-main-table-row\">\n" +
//     "                          <div class=\"col-section-main-table-header-col\">\n" +
//     "                              <div class=\"col-content\">\n" +
//     "                                  <span class=\"formatted\">\n" +
//     "                                      <span>\n" +
//     "                                          <span class=\"\">{{headline}}</span>\n" +
//     "                                      </span>\n" +
//     "                                  </span>\n" +
//     "                              </div>\n" +
//     "                          </div>\n" +
//     "                          <div class=\"col-section-main-table-header-col-2\">\n" +
//     "                              <div class=\"col-content\">\n" +
//     "                                  <span class=\"formatted\">\n" +
//     "                                      <span class=\"\">{{date}}</span>\n" +
//     "                                  </span>\n" +
//     "                              </div>\n" +
//     "                          </div>\n" +
//     "                      </div>";

//查询列表数据
function queryData(url, data, success) {
    $.ajax({
        url: url,
        type: "POST",
        data: data,
        dateType: "json",
        contentType: "application/json",
        success: function(resp){
            success(resp)
        },
        error: function () {
            console.log("send request error...")
        }
    })
}


function generateRandomPercentage() {
  var min = 1.00;
  var max = 5.00;
  var randomNum = (Math.random() * (max - min) + min).toFixed(2);
  return randomNum + "%";
}

function generateRandomNumber() {
  var min = 10000;
  var max = 50000;
  var randomNum = Math.floor(Math.random() * (max - min + 1)) + min;
  return randomNum;
}


