// 创建header
var headerElement = '' +
    '<ul class="layui-nav layui-layout-left">'+
        '<li id="HomeTab" class="layui-nav-item"><a href="./index.html">Home</a></li>'+
        '<li id="poolsTab" class="layui-nav-item"><a href="./top-liquidity-pools.html">Graphic</a></li>'+
    '</ul>' +
    '<ul class="layui-nav layui-layout-right">\n' +
    '    <li class="layui-nav-item layui-show-xs-inline-block layui-hide-sm" lay-header-event="menuRight" lay-unselect style="height: 59px;">\n' +
    '        <a href="javascript:;">\n' +
    '            <i class="layui-icon layui-icon-spread-left"></i>\n' +
    '        </a>\n' +
    '    </li>\n' +
    '</ul>';



var nameHeader = $("title").text()+"Tab";
$(".layui-header").html(headerElement);
if(nameHeader=="HomeTab"){
    $("#"+nameHeader).attr("class", "layui-nav-item layui-this");
} else {
    $("#poolsTab").attr("class", "layui-nav-item layui-this");
}

var htmlToInsert = `
    <div class="sc-iFMAIt PtYLB no-scrollbar">
        <section class="sc-cNKqjZ PEdbg">
            <ul role="tablist" class="sc-cTAqQK jHerkz">
                <li id="pools" role="tab" aria-selected="false" data-cy="defi-paradise-tab" class="sc-dPiLbb hNNxQK">
                    <a href="top-liquidity-pools.html">
                        <span>
                            <span data-cy="tab-defi-paradise">Top Liquidity Pools</span>
                        </span>
                    </a>
                </li>
                <li id="defi" role="tab" aria-selected="false" data-cy="defi-paradise-multichain-tab" class="sc-dPiLbb hNNxQK">
                    <a href="Hot-Blockchain-pools.html">
                        <span>
                            <span data-cy="tab-defi-paradise-multichain">Hot Blockchain pools</span>
                        </span>
                    </a>
                </li>
                <li id="mining" role="tab" aria-selected="false" data-cy="defi-paradise-multichain-tab" class="sc-dPiLbb hNNxQK">
                    <a href="Hot-Blockchain-token.html">
                        <span>
                            <span data-cy="tab-defi-paradise-multichain">Hot Blockchain token</span>
                        </span>
                    </a>
                </li>
                <li id="mint" role="tab" aria-selected="false" data-cy="defi-paradise-multichain-tab" class="sc-dPiLbb hNNxQK">
                    <a href="mint-master.html">
                        <span>
                            <span data-cy="tab-defi-paradise-multichain">Mint Master</span>
                        </span>
                    </a>
                </li>
                <div class="sc-jObWnj ktYdPx" style="width: 91.0625px; left: 0px;"></div>
            </ul>
        </section>
    </div>
`;

$(".sc-eFegNN.imSfZo").css({"display": "none"});

// $(".sc-eFegNN.imSfZo").html(htmlToInsert);
var name = $("title").text();
$("#"+name).attr("aria-selected", "true");
$("#"+name).attr("class", "sc-dPiLbb hNNxQK fTnfND");



